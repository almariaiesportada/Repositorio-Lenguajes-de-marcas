#!/usr/bin/env bash
set -e
rm -f "$HOME/.local/bin/agenda-notas-native"
rm -f "$HOME/.local/share/applications/agenda-notas-native.desktop"
rm -rf "$HOME/.local/share/agenda-notas-native"
printf 'Desinstalada correctamente.\n'
