import json
import os
import tkinter as tk
from tkinter import ttk, messagebox, filedialog
from pathlib import Path
from datetime import date

APP_NAME = 'Agenda de Notas'
DATA_DIR = Path.home() / '.local' / 'share' / 'agenda-notas-native'
DATA_FILE = DATA_DIR / 'data.json'


def ensure_data():
    DATA_DIR.mkdir(parents=True, exist_ok=True)
    if not DATA_FILE.exists():
        DATA_FILE.write_text(json.dumps({'subjects': []}, ensure_ascii=False, indent=2), encoding='utf-8')


def load_data():
    ensure_data()
    try:
        return json.loads(DATA_FILE.read_text(encoding='utf-8'))
    except Exception:
        return {'subjects': []}


def save_data(data):
    ensure_data()
    DATA_FILE.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding='utf-8')


def fmt(v):
    return '—' if v is None else f'{v:.2f}'


def calc_avg(subject):
    items = subject.get('items', [])
    total, weights = 0.0, 0.0
    for it in items:
        try:
            g = float(it['grade'])
            w = float(it['weight'])
        except Exception:
            continue
        if w > 0:
            total += g * w
            weights += w
    return None if weights <= 0 else total / weights


class App(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title(APP_NAME)
        self.geometry('1100x650')
        self.minsize(980, 580)
        self.data = load_data()
        self.current_subject_index = None
        self._build_ui()
        self.refresh_subjects()

    def _build_ui(self):
        style = ttk.Style(self)
        try:
            style.theme_use('clam')
        except Exception:
            pass
        self.columnconfigure(0, weight=0)
        self.columnconfigure(1, weight=1)
        self.rowconfigure(0, weight=1)

        left = ttk.Frame(self, padding=12)
        left.grid(row=0, column=0, sticky='ns')
        right = ttk.Frame(self, padding=12)
        right.grid(row=0, column=1, sticky='nsew')
        right.columnconfigure(0, weight=1)
        right.rowconfigure(3, weight=1)

        ttk.Label(left, text='Nueva asignatura', font=('TkDefaultFont', 12, 'bold')).grid(row=0, column=0, sticky='w')
        ttk.Label(left, text='Nombre').grid(row=1, column=0, sticky='w', pady=(8, 0))
        self.subject_name = ttk.Entry(left, width=28)
        self.subject_name.grid(row=2, column=0, sticky='ew')
        ttk.Label(left, text='Profesor/a').grid(row=3, column=0, sticky='w', pady=(8, 0))
        self.subject_teacher = ttk.Entry(left, width=28)
        self.subject_teacher.grid(row=4, column=0, sticky='ew')
        ttk.Label(left, text='Nota objetivo').grid(row=5, column=0, sticky='w', pady=(8, 0))
        self.subject_target = ttk.Entry(left, width=28)
        self.subject_target.grid(row=6, column=0, sticky='ew')
        ttk.Button(left, text='Añadir asignatura', command=self.add_subject).grid(row=7, column=0, sticky='ew', pady=(10, 0))
        ttk.Button(left, text='Cargar ejemplo', command=self.load_demo).grid(row=8, column=0, sticky='ew', pady=(6, 0))

        ttk.Separator(left).grid(row=9, column=0, sticky='ew', pady=12)
        ttk.Label(left, text='Asignaturas', font=('TkDefaultFont', 11, 'bold')).grid(row=10, column=0, sticky='w')
        self.subject_list = tk.Listbox(left, height=18, exportselection=False)
        self.subject_list.grid(row=11, column=0, sticky='nsew', pady=(6, 0))
        self.subject_list.bind('<<ListboxSelect>>', lambda e: self.on_select_subject())
        left.rowconfigure(11, weight=1)

        btns = ttk.Frame(left)
        btns.grid(row=12, column=0, sticky='ew', pady=(8, 0))
        btns.columnconfigure((0,1), weight=1)
        ttk.Button(btns, text='Exportar', command=self.export_data).grid(row=0, column=0, sticky='ew', padx=(0,4))
        ttk.Button(btns, text='Importar', command=self.import_data).grid(row=0, column=1, sticky='ew', padx=(4,0))
        ttk.Button(left, text='Borrar todo', command=self.reset_all).grid(row=13, column=0, sticky='ew', pady=(6, 0))

        self.title_var = tk.StringVar(value='Selecciona una asignatura')
        self.meta_var = tk.StringVar(value='Aquí verás tus notas y tu media.')
        ttk.Label(right, textvariable=self.title_var, font=('TkDefaultFont', 14, 'bold')).grid(row=0, column=0, sticky='w')
        ttk.Label(right, textvariable=self.meta_var).grid(row=1, column=0, sticky='w', pady=(4, 8))

        top_actions = ttk.Frame(right)
        top_actions.grid(row=2, column=0, sticky='ew', pady=(0, 8))
        ttk.Button(top_actions, text='Eliminar asignatura', command=self.delete_subject).pack(side='right')

        kpis = ttk.Frame(right)
        kpis.grid(row=3, column=0, sticky='ew')
        for i in range(3):
            kpis.columnconfigure(i, weight=1)
        self.avg_var = tk.StringVar(value='—')
        self.status_var = tk.StringVar(value='Sin notas')
        self.target_var = tk.StringVar(value='—')
        self._kpi(kpis, 'Media', self.avg_var, 0)
        self._kpi(kpis, 'Estado', self.status_var, 1)
        self._kpi(kpis, 'Objetivo', self.target_var, 2)

        form = ttk.LabelFrame(right, text='Añadir nota', padding=10)
        form.grid(row=4, column=0, sticky='ew', pady=(12, 8))
        for i in range(4):
            form.columnconfigure(i, weight=1)
        ttk.Label(form, text='Nombre').grid(row=0, column=0, sticky='w')
        self.item_name = ttk.Entry(form)
        self.item_name.grid(row=1, column=0, sticky='ew', padx=(0,6))
        ttk.Label(form, text='Tipo').grid(row=0, column=1, sticky='w')
        self.item_type = ttk.Combobox(form, values=['Examen','Tarea','Proyecto','Práctica','Otro'], state='readonly')
        self.item_type.set('Examen')
        self.item_type.grid(row=1, column=1, sticky='ew', padx=6)
        ttk.Label(form, text='Nota').grid(row=0, column=2, sticky='w')
        self.item_grade = ttk.Entry(form)
        self.item_grade.grid(row=1, column=2, sticky='ew', padx=6)
        ttk.Label(form, text='Peso').grid(row=0, column=3, sticky='w')
        self.item_weight = ttk.Entry(form)
        self.item_weight.insert(0, '1')
        self.item_weight.grid(row=1, column=3, sticky='ew', padx=(6,0))
        ttk.Label(form, text='Fecha').grid(row=2, column=0, sticky='w', pady=(8,0))
        self.item_date = ttk.Entry(form)
        self.item_date.insert(0, str(date.today()))
        self.item_date.grid(row=3, column=0, sticky='ew', padx=(0,6))
        ttk.Button(form, text='Guardar nota', command=self.add_item).grid(row=3, column=3, sticky='e')

        table_frame = ttk.Frame(right)
        table_frame.grid(row=5, column=0, sticky='nsew')
        right.rowconfigure(5, weight=1)
        cols = ('name', 'type', 'grade', 'weight', 'date')
        self.tree = ttk.Treeview(table_frame, columns=cols, show='headings', height=14)
        headings = [('name', 'Nombre'), ('type', 'Tipo'), ('grade', 'Nota'), ('weight', 'Peso'), ('date', 'Fecha')]
        for key, label in headings:
            self.tree.heading(key, text=label)
            self.tree.column(key, anchor='center')
        self.tree.column('name', anchor='w', width=250)
        self.tree.pack(side='left', fill='both', expand=True)
        scrollbar = ttk.Scrollbar(table_frame, orient='vertical', command=self.tree.yview)
        self.tree.configure(yscroll=scrollbar.set)
        scrollbar.pack(side='right', fill='y')

        bottom = ttk.Frame(right)
        bottom.grid(row=6, column=0, sticky='ew', pady=(8,0))
        self.help_var = tk.StringVar(value='La media es ponderada según el peso de cada nota.')
        ttk.Label(bottom, textvariable=self.help_var).pack(side='left')
        ttk.Button(bottom, text='Borrar nota seleccionada', command=self.delete_item).pack(side='right')

    def _kpi(self, parent, label, var, col):
        frame = ttk.LabelFrame(parent, text=label, padding=10)
        frame.grid(row=0, column=col, sticky='ew', padx=(0 if col == 0 else 6, 0), pady=(0, 0))
        ttk.Label(frame, textvariable=var, font=('TkDefaultFont', 15, 'bold')).pack(anchor='w')

    def current_subject(self):
        if self.current_subject_index is None:
            return None
        subs = self.data.get('subjects', [])
        if 0 <= self.current_subject_index < len(subs):
            return subs[self.current_subject_index]
        return None

    def refresh_subjects(self):
        self.subject_list.delete(0, tk.END)
        for subject in self.data.get('subjects', []):
            avg = calc_avg(subject)
            label = f"{subject['name']}  |  media: {fmt(avg)}"
            self.subject_list.insert(tk.END, label)
        if self.data.get('subjects'):
            if self.current_subject_index is None or self.current_subject_index >= len(self.data['subjects']):
                self.current_subject_index = 0
            self.subject_list.selection_clear(0, tk.END)
            self.subject_list.selection_set(self.current_subject_index)
            self.subject_list.activate(self.current_subject_index)
        else:
            self.current_subject_index = None
        self.refresh_detail()
        save_data(self.data)

    def refresh_detail(self):
        subject = self.current_subject()
        for row in self.tree.get_children():
            self.tree.delete(row)
        if not subject:
            self.title_var.set('Selecciona una asignatura')
            self.meta_var.set('Aquí verás tus notas y tu media.')
            self.avg_var.set('—')
            self.status_var.set('Sin notas')
            self.target_var.set('—')
            self.help_var.set('La media es ponderada según el peso de cada nota.')
            return
        avg = calc_avg(subject)
        self.title_var.set(subject['name'])
        teacher = subject.get('teacher') or '—'
        self.meta_var.set(f"Profesor/a: {teacher} · Media actual: {fmt(avg)}")
        self.avg_var.set(fmt(avg))
        self.status_var.set('Aprobado' if avg is not None and avg >= 5 else ('Suspenso' if avg is not None else 'Sin notas'))
        target = subject.get('target')
        self.target_var.set(fmt(float(target)) if target not in (None, '') else '—')
        if target not in (None, '') and avg is not None:
            diff = max(0.0, float(target) - avg)
            self.help_var.set(f'Te faltan aproximadamente {diff:.2f} puntos para llegar a tu objetivo.')
        else:
            self.help_var.set('La media es ponderada según el peso de cada nota.')
        for idx, item in enumerate(subject.get('items', [])):
            self.tree.insert('', 'end', iid=str(idx), values=(
                item.get('name',''), item.get('type',''), fmt(float(item.get('grade',0))), item.get('weight',''), item.get('date','') or '—'
            ))

    def on_select_subject(self):
        sel = self.subject_list.curselection()
        if not sel:
            return
        self.current_subject_index = sel[0]
        self.refresh_detail()

    def add_subject(self):
        name = self.subject_name.get().strip()
        teacher = self.subject_teacher.get().strip()
        target_raw = self.subject_target.get().strip()
        if not name:
            messagebox.showerror(APP_NAME, 'Escribe el nombre de la asignatura.')
            return
        target = None
        if target_raw:
            try:
                target = float(target_raw)
                if not (0 <= target <= 10):
                    raise ValueError
            except Exception:
                messagebox.showerror(APP_NAME, 'La nota objetivo debe estar entre 0 y 10.')
                return
        self.data['subjects'].append({'name': name, 'teacher': teacher, 'target': target, 'items': []})
        self.subject_name.delete(0, tk.END)
        self.subject_teacher.delete(0, tk.END)
        self.subject_target.delete(0, tk.END)
        self.current_subject_index = len(self.data['subjects']) - 1
        self.refresh_subjects()

    def delete_subject(self):
        subject = self.current_subject()
        if not subject:
            return
        if not messagebox.askyesno(APP_NAME, f'¿Eliminar la asignatura "{subject["name"]}"?'):
            return
        del self.data['subjects'][self.current_subject_index]
        self.current_subject_index = 0 if self.data['subjects'] else None
        self.refresh_subjects()

    def add_item(self):
        subject = self.current_subject()
        if not subject:
            messagebox.showerror(APP_NAME, 'Primero selecciona una asignatura.')
            return
        name = self.item_name.get().strip()
        kind = self.item_type.get().strip()
        grade_raw = self.item_grade.get().strip()
        weight_raw = self.item_weight.get().strip()
        dt = self.item_date.get().strip()
        if not name:
            messagebox.showerror(APP_NAME, 'Escribe un nombre para la nota.')
            return
        try:
            grade = float(grade_raw)
            if not (0 <= grade <= 10):
                raise ValueError
        except Exception:
            messagebox.showerror(APP_NAME, 'La nota debe estar entre 0 y 10.')
            return
        try:
            weight = float(weight_raw)
            if weight <= 0:
                raise ValueError
        except Exception:
            messagebox.showerror(APP_NAME, 'El peso debe ser mayor que 0.')
            return
        subject['items'].append({'name': name, 'type': kind, 'grade': grade, 'weight': weight, 'date': dt})
        self.item_name.delete(0, tk.END)
        self.item_grade.delete(0, tk.END)
        self.item_weight.delete(0, tk.END)
        self.item_weight.insert(0, '1')
        self.refresh_subjects()

    def delete_item(self):
        subject = self.current_subject()
        if not subject:
            return
        sel = self.tree.selection()
        if not sel:
            messagebox.showinfo(APP_NAME, 'Selecciona una nota para borrarla.')
            return
        idx = int(sel[0])
        del subject['items'][idx]
        self.refresh_subjects()

    def export_data(self):
        path = filedialog.asksaveasfilename(defaultextension='.json', filetypes=[('JSON', '*.json')], title='Exportar copia')
        if not path:
            return
        Path(path).write_text(json.dumps(self.data, ensure_ascii=False, indent=2), encoding='utf-8')
        messagebox.showinfo(APP_NAME, 'Copia exportada correctamente.')

    def import_data(self):
        path = filedialog.askopenfilename(filetypes=[('JSON', '*.json')], title='Importar copia')
        if not path:
            return
        try:
            data = json.loads(Path(path).read_text(encoding='utf-8'))
            if not isinstance(data.get('subjects'), list):
                raise ValueError
        except Exception:
            messagebox.showerror(APP_NAME, 'No se pudo importar el archivo.')
            return
        self.data = data
        self.current_subject_index = 0 if self.data['subjects'] else None
        self.refresh_subjects()

    def reset_all(self):
        if not messagebox.askyesno(APP_NAME, '¿Borrar todas las asignaturas y notas?'):
            return
        self.data = {'subjects': []}
        self.current_subject_index = None
        self.refresh_subjects()

    def load_demo(self):
        self.data = {
            'subjects': [
                {
                    'name': 'Matemáticas',
                    'teacher': 'María',
                    'target': 7.5,
                    'items': [
                        {'name': 'Examen 1', 'type': 'Examen', 'grade': 7.2, 'weight': 3, 'date': '2026-03-10'},
                        {'name': 'Tarea funciones', 'type': 'Tarea', 'grade': 8.6, 'weight': 1, 'date': '2026-03-14'}
                    ]
                },
                {
                    'name': 'Inglés',
                    'teacher': 'David',
                    'target': 8.0,
                    'items': [
                        {'name': 'Reading', 'type': 'Examen', 'grade': 8.1, 'weight': 2, 'date': '2026-03-11'},
                        {'name': 'Writing', 'type': 'Práctica', 'grade': 7.8, 'weight': 1, 'date': '2026-03-18'}
                    ]
                }
            ]
        }
        self.current_subject_index = 0
        self.refresh_subjects()


if __name__ == '__main__':
    App().mainloop()
