#!/usr/bin/env bash
set -e
BASE_DIR="$(cd "$(dirname "$0")" && pwd)"
INSTALL_DIR="$HOME/.local/share/agenda-notas-native"
BIN_DIR="$HOME/.local/bin"
APP_DIR="$HOME/.local/share/applications"
mkdir -p "$INSTALL_DIR" "$BIN_DIR" "$APP_DIR"
cp "$BASE_DIR/app.py" "$INSTALL_DIR/app.py"
cp "$BASE_DIR/agenda-notas-native" "$BIN_DIR/agenda-notas-native"
chmod +x "$BIN_DIR/agenda-notas-native"
sed "s|__HOME__|$HOME|g" "$BASE_DIR/agenda-notas-native.desktop" > "$APP_DIR/agenda-notas-native.desktop"
chmod +x "$APP_DIR/agenda-notas-native.desktop"
update-desktop-database "$APP_DIR" >/dev/null 2>&1 || true
printf '\nInstalada correctamente.\n'
printf 'Busca "Agenda de Notas Native" en el menú de aplicaciones.\n'
printf 'También puedes abrirla con: %s\n' "$BIN_DIR/agenda-notas-native"
